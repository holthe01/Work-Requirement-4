const statusMessage = document.querySelector("#status");

function getRatingGroup(rating) {
  if (rating < 3) return "Low ratings";
  if (rating < 4) return "Medium ratings";
  return "High ratings";
}

async function loadProducts() {
  try {
    const response = await fetch("https://fakestoreapi.com/products");
    if (!response.ok) {
      throw new Error(`Request failed (${response.status})`);
    }

    const products = await response.json();
    if (!Array.isArray(products) || products.length === 0) {
      throw new Error("The API returned no products.");
    }

    const productData = products.map((product) => ({
      title: product.title,
      category: product.category,
      rating: Number(product.rating?.rate),
    }));

    if (productData.some((product) =>
      typeof product.title !== "string" ||
      typeof product.category !== "string" ||
      !Number.isFinite(product.rating) ||
      product.rating < 0 ||
      product.rating > 5
    )) {
      throw new Error("The API returned invalid product rating data.");
    }

    renderCharts(productData);
    statusMessage.textContent = `Products loaded successfully. (${productData.length} products)`;
  } catch (error) {
    statusMessage.textContent = `Could not load products: ${error.message}`;
    statusMessage.classList.add("error");
  }
}

function renderCharts(products) {
  const categories = new Map();
  const ratingGroups = {
    "Low ratings": 0,
    "Medium ratings": 0,
    "High ratings": 0,
  };

  for (const product of products) {
    const category = categories.get(product.category) ?? { total: 0, count: 0 };
    category.total += product.rating;
    category.count += 1;
    categories.set(product.category, category);

    ratingGroups[getRatingGroup(product.rating)] += 1;
  }

  const categoryData = [...categories.entries()]
    .map(([name, values]) => ({
      name,
      y: Number((values.total / values.count).toFixed(2)),
    }))
    .sort((a, b) => a.name.localeCompare(b.name));

  Highcharts.chart("category-chart", {
    chart: { type: "column" },
    title: { text: "Average Rating by Category" },
    xAxis: {
      categories: categoryData.map((item) => item.name),
      title: { text: "Product category" },
    },
    yAxis: {
      min: 0,
      max: 5,
      tickInterval: 1,
      endOnTick: false,
      title: { text: "Average rating (0–5)" },
    },
    tooltip: {
      pointFormat: "Average rating: <b>{point.y:.2f} / 5</b>",
    },
    plotOptions: {
      column: {
        color: "#2878b5",
      },
    },
    series: [{
      name: "Average rating",
      data: categoryData.map((item) => item.y),
    }],
    accessibility: {
      enabled: true,
      description: "Average customer rating for each product category, from zero to five.",
    },
    credits: { enabled: false },
  });

  Highcharts.chart("distribution-chart", {
    chart: { type: "pie" },
    title: { text: "Product Rating Distribution" },
    tooltip: {
      pointFormat: "<b>{point.y}</b> products ({point.percentage:.1f}%)",
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: "pointer",
        showInLegend: true,
        dataLabels: { enabled: true, format: "{point.name}: {point.y}" },
      },
    },
    series: [{
      name: "Products",
      colorByPoint: true,
      data: Object.entries(ratingGroups).map(([name, y]) => ({ name, y })),
    }],
    accessibility: {
      enabled: true,
      description: "Number of products with low, medium and high customer ratings.",
    },
    credits: { enabled: false },
  });
}

loadProducts();
